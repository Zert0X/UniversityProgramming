Нормальное качество не влезает в 100КБ отправляю ссылку на диск

https://docs.google.com/document/d/1xgCDHPXlP_Scn5knQKw4QtQBBepbTW4o/edit?usp=sharing&ouid=113351288061364869554&rtpof=true&sd=true
