#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double x=1.5,y;
    y=(log(x+1)/log(3))-pow(sin(cos(x)),3)+(log(pow(x,((2/5)+pow(M_E,(x+1)))))-15*cos((pow(sin(x),3))))-((cos(x+1)*sin(x)/3)+pow(x,log(x)));
    cout <<"y= "<<y << endl;
    return 0;
}
